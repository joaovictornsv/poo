#include "Carro.h"

int main() {
  
  Carro carroTeste1("", 2001);

  carroTeste1.displayMessage();

  Carro carroTeste2("Uma marca bem grande", 2019);
  carroTeste2.displayMessage();

  return 0;
}